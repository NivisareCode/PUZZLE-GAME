function adilandin(param1,param2){
    var dpi = window.devicePixelRatio||1;
    var bsr = param1.webkitBackingStorePixelRatio ||
        param1.mozBackingStorePixelRatio ||
        param1.msBackingStorePixelRatio ||
        param1.oBackingStorePixelRatio ||
        param1.backingStorePixelRatio || 1;
    var style_height = +getComputedStyle(param2).getPropertyValue("height").slice(0, -2);
    var style_width = +getComputedStyle(param2).getPropertyValue("width").slice(0, -2);
    param2.setAttribute('height', style_height * dpi);
    param2.setAttribute('width', style_width * dpi);
    param2.setAttribute('height', style_height * bsr);
    param2.setAttribute('width', style_width * bsr);

}