function xizik(ctx,ufkixizik,amudixizik,w,h){
    for(i=0;i<amudixizik+1;i++){
        ctx.strokeStyle='grey';
        ctx.beginPath();
        ctx.moveTo(((i*w)/10),0);
        ctx.lineTo(((i*w)/10),h);
        ctx.stroke();
        ctx.closePath();
    }
    for(i=0;i<ufkixizik+1;i++){
        ctx.strokeStyle='grey';
        ctx.beginPath();
        ctx.moveTo(0,((i*h)/10));
        ctx.lineTo(w,((i*h)/10));
        ctx.stroke();
        ctx.closePath();
    }
}
function cellxizke(wcell,hcell,cnvs,imgkey,hejmar,img,i,k,imgid){
//var cellVar=[];

//var hejmar=0;
    $('<canvas class="cell"></canvas>').css({'width':wcell,'height':hcell}).appendTo('#koti');
    //cellVar.push({'cellkey':'cellvalue'+hejmar,'ctxkey':'ctxvalue'+hejmar,'imgkey':'imgvalue'+hejmar});

    var cellkey=document.getElementsByClassName('cell')[hejmar];
    var ctxkey=cellkey.getContext("2d");
    adilandin(ctxkey,cellkey);
    ctxkey.save();
    ctxkey.strokeStyle='black';
    ctxkey.beginPath();
    ctxkey.moveTo(0,0);
    ctxkey.lineTo(wcell,0);
    ctxkey.lineTo(wcell,hcell);
    ctxkey.lineTo(0,hcell);
    ctxkey.closePath();
    ctxkey.clip();
    ctxkey.drawImage(img,i*wcell,k*hcell,wcell,hcell,0,0,wcell,hcell);
    //TabPos.push({'id':'img'+hejmar,'x':i*wcell,'y':k*hcell});
    var dataURL=cellkey.toDataURL();

    var imgkey = $('<img class="derve">').css({'position':'absolute','width':wcell,'height':hcell}).attr('draggable','true'); //Equivalent: $(document.createElement('img'))

    imgkey.attr('src', dataURL);
    imgkey.attr('id', imgid);
    imgkey.appendTo('#koti');
    var X = $('#koti').offset().left+1;
    var Y = $('#koti').offset().top+1;
    //var wbtn=$('#btn').width();
    //$('#btn').offset({top:(Y+cnvs.height+65),left:(X+(cnvs.width/2)-50)})
    imgkey.offset({ top: (Y+250), left: (X+(cnvs.width)+90)});
}


function ufkiNigar(ctx3,a,w,r1,wcell,hcell,arrNum,hıjmar,jorData,jerData,caviData){
    var num=0;
    for(var i=0;i<10;i++){
        for(var k=0;k<10;k++){

            var item = arrNum[Math.floor(Math.random() * arrNum.length)];
            if(k==0){
                jorData.push(0);
               // jorData.push('duz');
            }else{
                jorData.push(item);
                //if(item<0){jorData}
            }
            if(k==9){
                jerData.push(0);
                //jerData[num].jer=0;
            }else{
                jerData.push(item);

                //jerData[num].jer=item;
            }
           /* caviData[num].jor=jorData[num];
            caviData[num].jer=jerData[num];*/
            num++;
            var x=k*wcell;
            var y=i*hcell;

            /*ctx3.font="bold 7pt arial";
            ctx3.textAlign="center";
            ctx3.fillText("K:"+k,x+wcell/2,y+(hcell/2));
            ctx3.fillText("İ:"+i,x+wcell/2,y+(hcell/2)+10);*/
            if(num<=10){continue;}
            ctx3.beginPath();
            ctx3.moveTo(x,y);
            ctx3.lineTo(x+w,y);

            if(item==-1){
                ctx3.arc(x+w,y-r1,r1,(1/2)*Math.PI,(5/3)*Math.PI,true);
                ctx3.arc(x+w+r1,y-3*r1,r1,(2/3)*Math.PI,(3/2)*Math.PI);
                ctx3.lineTo(x+w+r1+a,y-r1*(2+Math.round(2*Math.sin(60*Math.PI/180))));
                ctx3.arc(x+w+r1+a,y-3*r1,r1,(3/2)*Math.PI,(1/3)*Math.PI);
                ctx3.arc(x+w+a+2*r1,y-r1,r1,(4/3)*Math.PI,(1/2)*Math.PI,true);
            }else{
                ctx3.arc(x+w,y+r1,r1,(3/2)*Math.PI,(1/6)*Math.PI);
                ctx3.arc(x+w+r1,y+3*r1,r1,(4/3)*Math.PI,(1/2)*Math.PI,true);
                ctx3.lineTo(x+w+r1+a,y+r1*(2+Math.round(2*Math.sin(60*Math.PI/180))));
                ctx3.arc(x+w+r1+a,y+3*r1,r1,(1/2)*Math.PI,(5/3)*Math.PI,true);
                ctx3.arc(x+w+a+2*r1,y+r1,r1,(2/3)*Math.PI,(3/2)*Math.PI);
            }
            ctx3.lineTo(x+2*w+a+2*r1,y);
            ctx3.stroke();

        }
    }
}
function amudiNigar(ctx3,a,h,r1,wcell,hcell,arrNum,hıjmar,capData,rastData,caviData){
    var num=0;
    for(var i=0;i<10;i++){
        for(var k=0;k<10;k++){
            var item = arrNum[Math.floor(Math.random() * arrNum.length)];

            if(i==0){
                capData.push(0);
                //capData[num].cap=0;
            }else {
                capData.push(item);
                //capData[num].cap=item;
            }
            if(i==9){
                rastData.push(0);
                //rastData[num].rast=0;
            }else {
                rastData.push(item);
                //rastData[num].rast=item;
            }
            /*caviData[num].cap=capData[num];
            caviData[num].rast=rastData[num];*/
            num++;
            var x=i*wcell;
            var y=k*hcell;

            ctx3.font="bold 7pt arial";
            ctx3.textAlign="center";
            ctx3.fillText("K:"+k,x+wcell/2,y+(hcell/2));
            ctx3.fillText("İ:"+i,x+wcell/2,y+(hcell/2)+10);
            if(num<=10){continue;}
            ctx3.beginPath();
            ctx3.moveTo(x,y);
            ctx3.lineTo(x,y+h);
            if(item==-1){
                ctx3.arc(x-r1,y+h,r1,0,(5/6)*Math.PI);
                ctx3.arc(x-3*r1,y+h+r1,r1,(11/6)*Math.PI,1*Math.PI,true);
                ctx3.lineTo(x-r1*(2+Math.round(2*Math.sin(60*Math.PI/180))),y+h+r1+a);
                ctx3.arc(x-3*r1,y+h+r1+a,r1,1*Math.PI,(1/6)*Math.PI,true);
                ctx3.arc(x-r1,y+h+a+2*r1,r1,(7/6)*Math.PI,0);
            }else{
                ctx3.arc(x+r1,y+h,r1,1*Math.PI,(1/6)*Math.PI,true);
                ctx3.arc(x+3*r1,y+h+r1,r1,(7/6)*Math.PI,0);
                ctx3.lineTo(x+r1*(2+Math.round(2*Math.sin(60*Math.PI/180))),y+h+r1+a);
                ctx3.arc(x+3*r1,y+h+r1+a,r1,0,(5/6)*Math.PI);
                ctx3.arc(x+r1,y+h+a+2*r1,r1,(11/6)*Math.PI,1*Math.PI,true);
            }
            ctx3.lineTo(x,y+a+2*h+2*r1);
            ctx3.stroke();

        }
    }
}
function caviXizke(wene,a,h,w,r,wcell,hcell,jor,rast,jer,cap,caviX,caviY){
    var caviW=wcell,caviH=hcell;
    var b1=0,c1=0,b2=0,c2=0;
    var hıjmar=0;
    for(var i=0;i<caviX;i++){
        for(var k=0;k<caviY;k++){
            var ctxkey='ctxval'+hıjmar;
            var cnvskey='cnvsval'+hıjmar;
            var imgkey='imgval'+hıjmar;
            var imgid='imgid'+hıjmar;
            İf(jor[hıjmar]==='derve')
            {
                c1=r*(2+Math.round(2*Math.sin(60*Math.PI/180)));
                caviH=caviH+c1;
            }
            İf(rast[hıjmar]==='derve')
            {
                b2=r*(2+Math.round(2*Math.sin(60*Math.PI/180)));
                caviW=caviW+b2;
            }

            İf(jer[hıjmar]==='derve')
            {
                c2=r*(2+Math.round(2*Math.sin(60*Math.PI/180)));
                caviH=caviH+c2;
            }

            İf(cap[hıjmar]==='derve')
            {
                b1=r*(2+Math.round(2*Math.sin(60*Math.PI/180)));
                caviW=caviW+b1;
            }



            /*console.log(ctxkey);
            console.log(cnvskey);
            console.log(imgkey);
            console.log(imgid);
            console.log('b1:'+b1+' b2:'+b2+' c1:'+c1+' c2:'+c2);*/

            $('<canvas class="cell"></canvas>').css({'width':caviW,'height':caviH}).appendTo('body');
            /*cnvskey=document.getElementsByClassName('cell')[hıjmar];
            ctxkey=cnvskey.getContext('2d');
            ctxkey.beginPath();
            ctxkey.moveTo(orr,orr);
            ctxkey.clip()
            ctxkey.drawImage(img3,i*wcell,k*hcell,wcell,hcell,0,0,wcell,hcell);*/
            hıjmar++;
        }
    }

}

function nigarXizke(ctx,cnvs,jor,rast,jer,cap,r,a,w,h,caviX,caviY,cellNum,wcell,hcell,wene,TabPos,b1c1){
    var hıjmark=0;
    var caviW,caviH;
    var b1=0,c1=0,b2=0,c2=0;
    var x2=0,y2=0;
    //var hıjmar=0;
    for(var i=0;i<caviX;i++){
        for(var k=0;k<caviY;k++){
            caviW=wcell;
            caviH=hcell;
            //XİZKİRİNA NİGAR
            var x=k*wcell;
            var y=i*hcell;            
            ctx.beginPath();
            ctx.moveTo(x,y);
            if(jor[hıjmark]==='duz'){
                ctx.lineTo(x+wcell,y);
            }else if(jor[hıjmark]==='derve'){
                ctx.lineTo(x+w,y);
                ctx.arc(x+w,y-r,r,(1/2)*Math.PI,(5/3)*Math.PI,true);
                ctx.arc(x+w+r,y-3*r,r,(2/3)*Math.PI,(3/2)*Math.PI);
                ctx.lineTo(x+w+r+a,y-r*(2+Math.round(2*Math.sin(60*Math.PI/180))));
                ctx.arc(x+w+r+a,y-3*r,r,(3/2)*Math.PI,(1/3)*Math.PI);
                ctx.arc(x+w+a+2*r,y-r,r,(4/3)*Math.PI,(1/2)*Math.PI,true);
                ctx.lineTo(x+wcell,y);
            }else{
                ctx.lineTo(x+w,y);
                ctx.arc(x+w,y+r,r,(3/2)*Math.PI,(1/6)*Math.PI);
                ctx.arc(x+w+r,y+3*r,r,(4/3)*Math.PI,(1/2)*Math.PI,true);
                ctx.lineTo(x+w+r+a,y+r*(2+Math.round(2*Math.sin(60*Math.PI/180))));
                ctx.arc(x+w+r+a,y+3*r,r,(1/2)*Math.PI,(5/3)*Math.PI,true);
                ctx.arc(x+w+a+2*r,y+r,r,(2/3)*Math.PI,(3/2)*Math.PI);
                ctx.lineTo(x+wcell,y);
            }
            if(rast[hıjmark]==='duz'){
                ctx.lineTo(x+wcell,y+hcell);
            }else if(rast[hıjmark]==='derve'){
                ctx.lineTo(x+wcell,y+h);
                ctx.arc(x+wcell+r,y+h,r,1*Math.PI,(1/6)*Math.PI,true);
                ctx.arc(x+wcell+3*r,y+h+r,r,(7/6)*Math.PI,0);
                ctx.lineTo(x+wcell+r*(2+Math.round(2*Math.sin(60*Math.PI/180))),y+h+r+a);
                ctx.arc(x+wcell+3*r,y+h+r+a,r,0,(5/6)*Math.PI);
                ctx.arc(x+wcell+r,y+h+a+2*r,r,(11/6)*Math.PI,1*Math.PI,true);
                ctx.lineTo(x+wcell,y+a+2*h+2*r);
            }else{
                ctx.lineTo(x+wcell,y+h);
                ctx.arc(x+wcell-r,y+h,r,0,(5/6)*Math.PI);
                ctx.arc(x+wcell-3*r,y+h+r,r,(11/6)*Math.PI,Math.PI,true);
                ctx.lineTo(x+wcell-r*(2+Math.round(2*Math.sin(60*Math.PI/180))),y+h+r+a);
                ctx.arc(x+wcell-3*r,y+h+r+a,r,1*Math.PI,(1/6)*Math.PI,true);
                ctx.arc(x+wcell-r,y+h+a+2*r,r,(7/6)*Math.PI,0);
                ctx.lineTo(x+wcell,y+a+2*h+2*r);
            }
            if(jer[hıjmark]==='duz'){
                ctx.lineTo(x,y+hcell);
            }else if(jer[hıjmark]==='derve'){
                ctx.lineTo(x+wcell-w,y+hcell);
                ctx.arc(x+wcell-w,y+hcell+r,r,(3/2)*Math.PI,(2/3)*Math.PI,true);
                ctx.arc(x+wcell-w-r,y+hcell+3*r,r,(5/3)*Math.PI,(1/2)*Math.PI);
                ctx.lineTo(x+wcell-w-r-a,y+hcell+r*(2+Math.round(2*Math.sin(60*Math.PI/180))));
                ctx.arc(x+wcell-w-r-a,y+hcell+3*r,r,(1/2)*Math.PI,(4/3)*Math.PI);
                ctx.arc(x+wcell-w-a-2*r,y+hcell+r,r,(1/3)*Math.PI,(3/2)*Math.PI,true);
                ctx.lineTo(x,y+hcell);
            }else{
                ctx.lineTo(x+wcell-w,y+hcell);
                ctx.arc(x+wcell-w,y+hcell-r,r,(1/2)*Math.PI,(4/3)*Math.PI);
                ctx.arc(x+wcell-w-r,y+hcell-3*r,r,(1/3)*Math.PI,(3/2)*Math.PI,true);
                ctx.lineTo(x+wcell-w-r-a,y+hcell-r*(2+Math.round(2*Math.sin(60*Math.PI/180))));
                ctx.arc(x+wcell-w-r-a,y+hcell-3*r,r,(3/2)*Math.PI,(2/3)*Math.PI,true);
                ctx.arc(x+wcell-w-a-2*r,y+hcell-r,r,(5/3)*Math.PI,(1/2)*Math.PI);
                ctx.lineTo(x,y+hcell);
            }
            if(cap[hıjmark]==='duz'){
                ctx.lineTo(x,y);
            }else if(cap[hıjmark]==='derve'){
                ctx.lineTo(x,y+hcell-h);
                ctx.arc(x-r,y+hcell-h,r,0,(7/6)*Math.PI,true);
                ctx.arc(x-3*r,y+hcell-h-r,r,(1/6)*Math.PI,Math.PI);
                ctx.lineTo(x-r*(2+Math.round(2*Math.sin(60*Math.PI/180))),y+hcell-h-r-a);
                ctx.arc(x-3*r,y+h+r,r,Math.PI,(11/6)*Math.PI);
                ctx.arc(x-r,y+h,r,(5/6)*Math.PI,0,true);
                ctx.lineTo(x,y);
            }else{
                ctx.lineTo(x,y+hcell-h);
                ctx.arc(x+r,y+hcell-h,r,Math.PI,(11/6)*Math.PI);
                ctx.arc(x+3*r,y+hcell-h-r,r,(5/6)*Math.PI,0,true);
                ctx.lineTo(x+r*(2+Math.round(2*Math.sin(60*Math.PI/180))),y+hcell-h-r-a);
                ctx.arc(x+3*r,y+h+r,r,0,(7/6)*Math.PI,true);
                ctx.arc(x+r,y+h,r,(1/6)*Math.PI,Math.PI);
                ctx.lineTo(x,y);
            }
            ctx.stroke();
            ctx.closePath();
            
            //XİZKİRİNA MALIKAN
            var ctxkey='ctxval'+hıjmark;
            var cnvskey='cnvsval'+hıjmark;
            var imgkey='imgval'+hıjmark;
            var imgid='imgid'+hıjmark;


            if(jor[hıjmark]==='derve'){
                c1=r*(2+Math.round(2*Math.sin(60*Math.PI/180)))+1;
                caviH=caviH+c1;
                b1c1.push({'c1':c1});
            }else{
                c1=0;
                caviH=caviH+c1;
                b1c1.push({'c1':c1});
            }
            if(cap[hıjmark]==='derve'){
                b1=r*(2+Math.round(2*Math.sin(60*Math.PI/180)))+1;
                caviW=caviW+b1;
                b1c1.push({'b1':b1});
            }else{
                b1=0;
                caviW=caviW+b1;
                b1c1.push({'b1':b1});
            }
            if(jer[hıjmark]==='derve'){
                c2=r*(2+Math.round(2*Math.sin(60*Math.PI/180)));
                caviH=caviH+c2;
                b1c1.push({'c2':c2});
            }else{
                c2=0;
                caviH=caviH+c2;
                b1c1.push({'c2':c2});
            }
            if(rast[hıjmark]==='derve'){
                b2=r*(2+Math.round(2*Math.sin(60*Math.PI/180)));
                caviW=caviW+b2;
                b1c1.push({'b2':b2});
            }else{
                b2=0;
                caviW=caviW+b2;
                b1c1.push({'b2':b2});
            }
            TabPos.push({'id': imgid, 'x': k * wcell-b1, 'y': i * hcell-c1});
            
            $('<canvas class="cell"></canvas>').css({'width':caviW+'px','height':caviH+'px'}).appendTo('body');
            cnvskey=document.getElementsByClassName('cell')[hıjmark];
            ctxkey=cnvskey.getContext('2d');
            adilandin(ctxkey,cnvskey);

            ctxkey.beginPath();
            ctxkey.strokeStyle='transparent';
            ctxkey.moveTo(x2+b1,y2+c1);
            if(jor[hıjmark]==='duz'){
                ctxkey.lineTo(x2+b1+wcell,y2+c1);
            }else if(jor[hıjmark]==='derve'){
                ctxkey.lineTo(x2+b1+w,y2+c1);
                ctxkey.arc(x2+b1+w,y2+c1-r,r,(1/2)*Math.PI,(5/3)*Math.PI,true);
                ctxkey.arc(x2+b1+w+r,y2+c1-3*r,r,(2/3)*Math.PI,(3/2)*Math.PI);
                ctxkey.lineTo(x2+b1+w+r+a,y2+c1-r*(2+Math.round(2*Math.sin(60*Math.PI/180))));
                ctxkey.arc(x2+b1+w+r+a,y2+c1-3*r,r,(3/2)*Math.PI,(1/3)*Math.PI);
                ctxkey.arc(x2+b1+w+a+2*r,y2+c1-r,r,(4/3)*Math.PI,(1/2)*Math.PI,true);
                ctxkey.lineTo(x2+b1+wcell,y2+c1);
            }else{
                ctxkey.lineTo(x2+b1+w,y2+c1);
                ctxkey.arc(x2+b1+w,y2+c1+r,r,(3/2)*Math.PI,(1/6)*Math.PI);
                ctxkey.arc(x2+b1+w+r,y2+c1+3*r,r,(4/3)*Math.PI,(1/2)*Math.PI,true);
                ctxkey.lineTo(x2+b1+w+r+a,y2+c1+r*(2+Math.round(2*Math.sin(60*Math.PI/180))));
                ctxkey.arc(x2+b1+w+r+a,y2+c1+3*r,r,(1/2)*Math.PI,(5/3)*Math.PI,true);
                ctxkey.arc(x2+b1+w+a+2*r,y2+c1+r,r,(2/3)*Math.PI,(3/2)*Math.PI);
                ctxkey.lineTo(x2+b1+wcell,y2+c1);
            }
            if(rast[hıjmark]==='duz'){
                ctxkey.lineTo(x2+b1+wcell,y2+c1+hcell);
            }else if(rast[hıjmark]==='derve'){
                ctxkey.lineTo(x2+b1+wcell,y2+c1+h);
                ctxkey.arc(x2+b1+wcell+r,y2+c1+h,r,1*Math.PI,(1/6)*Math.PI,true);
                ctxkey.arc(x2+b1+wcell+3*r,y2+c1+h+r,r,(7/6)*Math.PI,0);
                ctxkey.lineTo(x2+b1+wcell+r*(2+Math.round(2*Math.sin(60*Math.PI/180))),y2+c1+h+r+a);
                ctxkey.arc(x2+b1+wcell+3*r,y2+c1+h+r+a,r,0,(5/6)*Math.PI);
                ctxkey.arc(x2+b1+wcell+r,y2+c1+h+a+2*r,r,(11/6)*Math.PI,1*Math.PI,true);
                ctxkey.lineTo(x2+b1+wcell,y2+c1+a+2*h+2*r);
            }else{
                ctxkey.lineTo(x2+b1+wcell,y2+c1+h);
                ctxkey.arc(x2+b1+wcell-r,y2+c1+h,r,0,(5/6)*Math.PI);
                ctxkey.arc(x2+b1+wcell-3*r,y2+c1+h+r,r,(11/6)*Math.PI,Math.PI,true);
                ctxkey.lineTo(x2+b1+wcell-r*(2+Math.round(2*Math.sin(60*Math.PI/180))),y2+c1+h+r+a);
                ctxkey.arc(x2+b1+wcell-3*r,y2+c1+h+r+a,r,1*Math.PI,(1/6)*Math.PI,true);
                ctxkey.arc(x2+b1+wcell-r,y2+c1+h+a+2*r,r,(7/6)*Math.PI,0);
                ctxkey.lineTo(x2+b1+wcell,y2+c1+a+2*h+2*r);
            }
            if(jer[hıjmark]==='duz'){
                ctxkey.lineTo(x2+b1,y2+c1+hcell);
            }else if(jer[hıjmark]==='derve'){
                ctxkey.lineTo(x2+b1+wcell-w,y2+c1+hcell);
                ctxkey.arc(x2+b1+wcell-w,y2+c1+hcell+r,r,(3/2)*Math.PI,(2/3)*Math.PI,true);
                ctxkey.arc(x2+b1+wcell-w-r,y2+c1+hcell+3*r,r,(5/3)*Math.PI,(1/2)*Math.PI);
                ctxkey.lineTo(x2+b1+wcell-w-r-a,y2+c1+hcell+r*(2+Math.round(2*Math.sin(60*Math.PI/180))));
                ctxkey.arc(x2+b1+wcell-w-r-a,y2+c1+hcell+3*r,r,(1/2)*Math.PI,(4/3)*Math.PI);
                ctxkey.arc(x2+b1+wcell-w-a-2*r,y2+c1+hcell+r,r,(1/3)*Math.PI,(3/2)*Math.PI,true);
                ctxkey.lineTo(x2+b1,y2+c1+hcell);
            }else{
                ctxkey.lineTo(x2+b1+wcell-w,y2+c1+hcell);
                ctxkey.arc(x2+b1+wcell-w,y2+c1+hcell-r,r,(1/2)*Math.PI,(4/3)*Math.PI);
                ctxkey.arc(x2+b1+wcell-w-r,y2+c1+hcell-3*r,r,(1/3)*Math.PI,(3/2)*Math.PI,true);
                ctxkey.lineTo(x2+b1+wcell-w-r-a,y2+c1+hcell-r*(2+Math.round(2*Math.sin(60*Math.PI/180))));
                ctxkey.arc(x2+b1+wcell-w-r-a,y2+c1+hcell-3*r,r,(3/2)*Math.PI,(2/3)*Math.PI,true);
                ctxkey.arc(x2+b1+wcell-w-a-2*r,y2+c1+hcell-r,r,(5/3)*Math.PI,(1/2)*Math.PI);
                ctxkey.lineTo(x2+b1,y2+c1+hcell);
            }
            if(cap[hıjmark]==='duz'){
                ctxkey.lineTo(x2+b1,y2+c1);
            }else if(cap[hıjmark]==='derve'){
                ctxkey.lineTo(x2+b1,y2+c1+hcell-h);
                ctxkey.arc(x2+b1-r,y2+c1+hcell-h,r,0,(7/6)*Math.PI,true);
                ctxkey.arc(x2+b1-3*r,y2+c1+hcell-h-r,r,(1/6)*Math.PI,Math.PI);
                ctxkey.lineTo(x2+b1-r*(2+Math.round(2*Math.sin(60*Math.PI/180))),y2+c1+hcell-h-r-a);
                ctxkey.arc(x2+b1-3*r,y2+c1+h+r,r,Math.PI,(11/6)*Math.PI);
                ctxkey.arc(x2+b1-r,y2+c1+h,r,(5/6)*Math.PI,0,true);
                ctxkey.lineTo(x2+b1,y2+c1);
            }else{
                ctxkey.lineTo(x2+b1,y2+c1+hcell-h);
                ctxkey.arc(x2+b1+r,y2+c1+hcell-h,r,Math.PI,(11/6)*Math.PI);
                ctxkey.arc(x2+b1+3*r,y2+c1+hcell-h-r,r,(5/6)*Math.PI,0,true);
                ctxkey.lineTo(x2+b1+r*(2+Math.round(2*Math.sin(60*Math.PI/180))),y2+c1+hcell-h-r-a);
                ctxkey.arc(x2+b1+3*r,y2+c1+h+r,r,0,(7/6)*Math.PI,true);
                ctxkey.arc(x2+b1+r,y2+c1+h,r,(1/6)*Math.PI,Math.PI);
                ctxkey.lineTo(x2+b1,y2+c1);
            }
            ctxkey.stroke();
            ctxkey.closePath();
            ctxkey.clip();
            ctxkey.drawImage(wene,k*wcell-b1,i*hcell-c1,caviW,caviH,0,0,caviW,caviH);
            //console.log(hıjmark+'-)wcell:'+wcell+' hcell:'+hcell+' caviW:'+caviW+' caviH:'+caviH);
            var dataURL=cnvskey.toDataURL();
            var imgkey = $('<img class="derve">').css({'position':'absolute','width':caviW+'px','height':caviH+'px'}).attr('draggable','true'); //Equivalent: $(document.createElement('img'))
            imgkey.attr('src', dataURL);
            imgkey.attr('id', imgid);
            imgkey.appendTo('#container');
            var X = $('#container').offset().left+1;
            var Y = $('#container').offset().top+1;
            //$(this).offset({ top: (y1+290), left: (x1+(cnvs.width)+65)});
            imgkey.offset({ top: (Y+330), left: (X+(cnvs.width)+105)});
            //imgkey.offset({ top: (Y+290), left: (X+(cnvs.width)+65)});
            imgkey.css({transform: 'translate(-50%,-50%)'});
            hıjmark++;
        }
    }

}